package com.bloom.employee.model;

public enum Shift {

    A , B , C

}
