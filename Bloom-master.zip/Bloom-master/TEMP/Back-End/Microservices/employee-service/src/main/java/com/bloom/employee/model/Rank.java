package com.bloom.employee.model;

public enum Rank {

    ONE , TWO , THREE , FOUR , FIVE

}
