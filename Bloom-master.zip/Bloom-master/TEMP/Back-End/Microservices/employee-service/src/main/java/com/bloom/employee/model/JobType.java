package com.bloom.employee.model;

public enum JobType {

    DOCTOR , NURSE , EMPLOYEE

}
