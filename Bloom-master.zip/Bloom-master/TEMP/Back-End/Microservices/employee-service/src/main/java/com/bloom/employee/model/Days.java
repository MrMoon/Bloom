package com.bloom.employee.model;

public enum Days {

    MONDAY, SUNDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY


}
