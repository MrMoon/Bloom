package com.bloom.patient.model;

public enum Gender {

    MALE , FEMALE

}
