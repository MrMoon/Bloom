package com.bloom.hospital.model;

public enum PatientEntryType {

    EMERGENCY , OPD , ROUTINE_CHECK_UP;

}
