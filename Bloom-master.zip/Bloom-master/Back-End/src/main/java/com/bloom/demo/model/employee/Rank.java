package com.bloom.demo.model.employee;

public enum Rank {

    ONE, TWO, THREE, FOUR, FIVE

}
