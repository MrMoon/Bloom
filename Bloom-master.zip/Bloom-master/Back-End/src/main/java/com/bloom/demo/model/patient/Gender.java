package com.bloom.demo.model.patient;

public enum Gender {

    MALE, FEMALE

}
