package com.bloom.demo.model.employee;

public enum JobType {

    DOCTOR, NURSE, EMPLOYEE

}
