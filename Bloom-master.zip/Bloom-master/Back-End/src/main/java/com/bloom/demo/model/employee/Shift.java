package com.bloom.demo.model.employee;

public enum Shift {

    A, B, C

}
