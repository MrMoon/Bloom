package com.bloom.demo.model.hospital;

public enum PatientEntryType {

    EMERGENCY, OPD, ROUTINE_CHECK_UP

}
