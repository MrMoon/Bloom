
# Bloom
Bloom project is a hospital web application that is based on the Database Systemes project requirements
Build using 
 - Java
 - Spring
    - Core
    - Boot
    - REST DOCs
    - WebFlux
    - Data
    - Repository 
    - Cloud
 - Project Reactor
 - R2DBC
 - Angular
 - Postgres
