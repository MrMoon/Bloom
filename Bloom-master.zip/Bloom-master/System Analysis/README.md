# Bloom System Analysis and Design
- Includes some Documentations, which is going to be updated in the future
- Database Screenshots
- Data Modeling in ERR and UML Diagrams
